var dataString='<chart showBorder="1" caption="Yearly Sales" xAxisName="Year" yAxisName="Sales">\n\
<set label="2004" value="37800" link="newchart-xml-2004-quarterly" />\n\
<set label="2005" value="21900" link="newchart-xml-2005-quarterly" />\n\
<set label="2006" value="32900" link="newchart-xml-2006-quarterly" />\n\
<set label="2007" value="39800" link="newchart-xml-2007-quarterly" />\n\
<linkeddata id="2004-quarterly">\n\
<chart showBorder="1" caption="Quarterly Sales Summary" subcaption="For the year 2004"\n\
xAxisName="Quarter" yAxisName="Sales" >\n\
<set label="Q1" value="11700" />\n\
<set label="Q2" value="8600" />\n\
<set label="Q3" value="6900" />\n\
<set label="Q4" value="10600" />\n\
</chart>\n\
</linkeddata>\n\
<linkeddata id="2005-quarterly">\n\
<chart showBorder="1" caption="Quarterly Sales Summary" subcaption="For the year 2005"\n\
xAxisName="Quarter" yAxisName="Sales">\n\
<set label="Q1" value="5500" />\n\
<set label="Q2" value="7100" />\n\
<set label="Q3" value="3900" />\n\
<set label="Q4" value="5400" />\n\
</chart>\n\
</linkeddata>\n\
<linkeddata id="2006-quarterly">\n\
<chart showBorder="1" caption="Quarterly Sales Summary" subcaption="For the year 2006"\n\
xAxisName="Quarter" yAxisName="Sales">\n\
<set label="Q1" value="6700" />\n\
<set label="Q2" value="9200" />\n\
<set label="Q3" value="10800" />\n\
<set label="Q4" value="6200" />\n\
</chart>\n\
</linkeddata>\n\
<linkeddata id="2007-quarterly">\n\
<chart showBorder="1" caption="Quarterly Sales Summary" subcaption="For the year 2007"\n\
xAxisName="Quarter" yAxisName="Sales">\n\
<set label="Q1" value="8900" />\n\
<set label="Q2" value="6600" />\n\
<set label="Q3" value="11200" />\n\
<set label="Q4" value="13100" />\n\
</chart>\n\
</linkeddata>\n\
</chart>';