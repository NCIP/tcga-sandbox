var dataString = '<chart caption="Monthly Unit Sales" xAxisName="Month" yAxisName="Units" showValues="0" decimals="0" formatNumberScale="0" labelDisplay="Rotate">\n\
<set label="Jan" value="462" />\n\
<set label="Feb" value="857" />\n\
<set label="Mar" value="671" />\n\
<set label="Apr" value="494" />\n\
<set label="May" value="761" />\n\
<set label="Jun" value="960" />\n\
<set label="Jul" value="629" />\n\
<set label="Aug" value="622" />\n\
<set label="Sep" value="376" />\n\
<set label="Oct" value="494" />\n\
<set label="Nov" value="761" />\n\
<set label="Dec" value="960" />\n\
</chart>';