For the application to work, please copy the following maps from Download Package > Maps folder to this folder:
- FCMap_World8.swf
- FCMap_USA.swf
- All 52 USA Maps

Alternatively, you may copy all the maps to this folder.
