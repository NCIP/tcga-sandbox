vti_encoding:SR|utf8-nl
vti_author:SR|IGPL\\Administrator
vti_modifiedby:SR|IGPL\\Administrator
vti_timecreated:TR|06 Jun 2007 12:52:20 -0000
vti_timelastmodified:TR|06 Jun 2007 12:52:20 -0000
vti_cacheddtm:TX|06 Jun 2007 12:52:20 -0000
vti_filesize:IR|7057
vti_extenderversion:SR|4.0.2.8912
vti_backlinkinfo:VX|fusionmapsv3/asp_db/charts.asp
