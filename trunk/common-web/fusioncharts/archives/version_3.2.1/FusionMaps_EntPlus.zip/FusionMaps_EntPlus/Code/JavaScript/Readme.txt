Important Instructions to follow before you execute examples in this folder
===========================================================================

Make sure you've copied pasted the files (including ../../Maps folder)
to your localhost (or any remove server). Since JavaScript is used for these
examples, they would not run on your local file system (as Adobe Flash Player
blocks Flash-JavaScript communication on local file system, unless otherwise
configured). If you do not take this step, the examples will fail silently.